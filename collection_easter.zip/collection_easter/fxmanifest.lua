-- FX Information --
fx_version   'cerulean'
lua54        'yes'
game         'gta5'

-- Resource Information --
name         'Collection Easter Props'
version      '1.0.1'
author       'DJ'
description  'Bundle Pack of Easter Props'

data_file 'DLC_ITYP_REQUEST' 'stream/easter.ytyp'

dependency '/assetpacks'